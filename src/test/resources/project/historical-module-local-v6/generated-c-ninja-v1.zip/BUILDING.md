# Build the reconstructed project

From this directory, run the following single parallel build command:

```sh
ninja -f build.ninja -j 4
```

The build requires Ninja, the configured C compiler `cc`, a POSIX shell, find, sort and tr. Warnings are errors and file/macro/debug paths are mapped to the project root. No Make invocation, API credentials, network access or analysis caches are required. Per-module diagnostics and the source-bound build contract are under `reports/`.
