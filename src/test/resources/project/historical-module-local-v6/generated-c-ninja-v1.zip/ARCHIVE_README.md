# Reconstructed archival source tree

This project was reconstructed from a binary using evidence-backed analysis and may not be universally equivalent to the original.

Build with the exact Ninja command in `BUILDING.md`. Source, build and module evidence are retained under `reports/`.
Verify payload hashes with `ARCHIVE_MANIFEST.sha256` before use.
