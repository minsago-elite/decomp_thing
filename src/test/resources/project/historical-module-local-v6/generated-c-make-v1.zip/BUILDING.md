# Build the reconstructed project

From this directory, run the following single parallel build command:

```sh
make --jobs=4 --output-sync=target CC=cc 'CFLAGS=-std=c11 -g -Wall -Wextra -Werror -Iinclude'
```

The build requires GNU Make, the configured C compiler `cc`, a POSIX shell, and the POSIX `find`, `mkdir`, and `rm` utilities. `-Werror` is mandatory. The generated Makefile maps file, macro, and debug paths to a project-relative root so identical accepted source revisions do not retain workstation paths. The build does not require analysis caches, network access, or API credentials. Per-module compiler diagnostics are written under `reports/build/modules/`; `reports/build_contract.json` maps every source to its owning module.
