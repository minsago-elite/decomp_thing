#include "decomp_types.h"
int parse_input(void);

int main(int argc, char **argv) {
    (void)argc;
    (void)argv;
    return parse_input();
}
