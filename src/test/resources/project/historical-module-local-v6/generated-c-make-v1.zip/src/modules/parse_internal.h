#ifndef DECOMP_MODULE_PARSE_INTERNAL_H
#define DECOMP_MODULE_PARSE_INTERNAL_H

#include "modules/parse.h"

int parse_input(void); /* private fn_0000000000401000 @ 0x401000 */

#endif
