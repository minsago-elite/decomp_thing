#include "modules/parse.h"
/* fn_0000000000401000 */
int parse_input(void) { return 17; }
